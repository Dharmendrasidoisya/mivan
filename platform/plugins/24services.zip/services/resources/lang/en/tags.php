<?php

return [
    'form' => [
        'name' => 'Name',
        'name_placeholder' => 'Tag\'s name (Maximum 120 characters)',
        'description' => 'Description',
        'description_placeholder' => 'Short description for stag (Maximum 400 characters)',
        'servicescategories' => 'servicescategories',
    ],
    'notices' => [
        'no_select' => 'Please select at least one stag to take this action!',
    ],
    'create' => 'Create new stag',
    'cannot_delete' => 'Tag could not be deleted',
    'deleted' => 'Tag deleted',
    'menu' => 'servicestags',
    'edit_this_tag' => 'Edit this stag',
    'menu_name' => 'servicestags',
];
